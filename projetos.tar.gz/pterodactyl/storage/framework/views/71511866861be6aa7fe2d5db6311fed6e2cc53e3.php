<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->getFromJson('base.account.header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <h1><?php echo app('translator')->getFromJson('base.account.header'); ?><small><?php echo app('translator')->getFromJson('base.account.header_sub'); ?></small></h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->getFromJson('strings.home'); ?></a></li>
        <li class="active"><?php echo app('translator')->getFromJson('strings.account'); ?></li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-6">
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title"><?php echo app('translator')->getFromJson('base.account.update_pass'); ?></h3>
                    </div>
                    <form action="<?php echo e(route('account')); ?>" method="post">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="current_password" class="control-label"><?php echo app('translator')->getFromJson('base.account.current_password'); ?></label>
                                <div>
                                    <input type="password" class="form-control" name="current_password" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="new_password" class="control-label"><?php echo app('translator')->getFromJson('base.account.new_password'); ?></label>
                                <div>
                                    <input type="password" class="form-control" name="new_password" />
                                    <p class="text-muted small no-margin"><?php echo app('translator')->getFromJson('auth.password_requirements'); ?></p>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="new_password_again" class="control-label"><?php echo app('translator')->getFromJson('base.account.new_password_again'); ?></label>
                                <div>
                                    <input type="password" class="form-control" name="new_password_confirmation" />
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <?php echo csrf_field(); ?>

                            <input type="hidden" name="do_action" value="password" />
                            <input type="submit" class="btn btn-primary btn-sm" value="<?php echo app('translator')->getFromJson('base.account.update_pass'); ?>" />
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-6">
        <div class="row">
            <div class="col-xs-12">
                <div class="box box-primary">
                    <form action="<?php echo e(route('account')); ?>" method="POST">
                        <div class="box-header with-border">
                            <h3 class="box-title"><?php echo app('translator')->getFromJson('base.account.update_identity'); ?></h3>
                        </div>
                        <div class="box-body">
                            <div class="row">
                                <div class="form-group col-sm-6">
                                    <label for="first_name" class="control-label"><?php echo app('translator')->getFromJson('base.account.first_name'); ?></label>
                                    <div>
                                        <input type="text" class="form-control" name="name_first" value="<?php echo e(Auth::user()->name_first); ?>" />
                                    </div>
                                </div>
                                <div class="form-group col-sm-6">
                                    <label for="last_name" class="control-label"><?php echo app('translator')->getFromJson('base.account.last_name'); ?></label>
                                    <div>
                                        <input type="text" class="form-control" name="name_last" value="<?php echo e(Auth::user()->name_last); ?>" />
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-xs-12">
                                    <label for="password" class="control-label"><?php echo app('translator')->getFromJson('strings.username'); ?></label>
                                    <div>
                                        <input type="text" class="form-control" name="username" value="<?php echo e(Auth::user()->username); ?>" />
                                        <p class="text-muted small no-margin"><?php echo app('translator')->getFromJson('base.account.username_help', [ 'requirements' => '<code>a-z A-Z 0-9 _ - .</code>']); ?></p>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-xs-12">
                                    <label for="language" class="control-label"><?php echo app('translator')->getFromJson('base.account.language'); ?></label>
                                    <div>
                                        <select name="language" id="language" class="form-control">
                                            <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($key); ?>" <?php echo e(Auth::user()->language !== $key ?: 'selected'); ?>><?php echo e($value); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="box-footer with-border">
                            <?php echo csrf_field(); ?>

                            <input type="hidden" name="do_action" value="identity" />
                            <button type="submit" class="btn btn-sm btn-primary"><?php echo app('translator')->getFromJson('base.account.update_identity'); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title"><?php echo app('translator')->getFromJson('base.account.update_email'); ?></h3>
                    </div>
                    <form action="<?php echo e(route('account')); ?>" method="post">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="new_email" class="control-label"><?php echo app('translator')->getFromJson('base.account.new_email'); ?></label>
                                <div>
                                    <input type="email" class="form-control" name="new_email" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="password" class="control-label"><?php echo app('translator')->getFromJson('base.account.current_password'); ?></label>
                                <div>
                                    <input type="password" class="form-control" name="current_password" />
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <?php echo csrf_field(); ?>

                            <input type="hidden" name="do_action" value="email" />
                            <input type="submit" class="btn btn-primary btn-sm" value="<?php echo app('translator')->getFromJson('base.account.update_email'); ?>" />
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>