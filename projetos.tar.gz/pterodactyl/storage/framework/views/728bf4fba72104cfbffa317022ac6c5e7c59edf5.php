<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->getFromJson('server.config.allocation.header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <h1><?php echo app('translator')->getFromJson('server.config.allocation.header'); ?><small><?php echo app('translator')->getFromJson('server.config.allocation.header_sub'); ?></small></h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->getFromJson('strings.home'); ?></a></li>
        <li><a href="<?php echo e(route('server.index', $server->uuidShort)); ?>"><?php echo e($server->name); ?></a></li>
        <li><?php echo app('translator')->getFromJson('navigation.server.configuration'); ?></li>
        <li class="active"><?php echo app('translator')->getFromJson('navigation.server.port_allocations'); ?></li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-8">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title"><?php echo app('translator')->getFromJson('server.config.allocation.available'); ?></h3>
            </div>
            <div class="box-body table-responsive no-padding">
                <table class="table table-hover">
                    <tbody>
                        <tr>
                            <th><?php echo app('translator')->getFromJson('strings.ip'); ?></th>
                            <th><?php echo app('translator')->getFromJson('strings.alias'); ?></th>
                            <th><?php echo app('translator')->getFromJson('strings.port'); ?></th>
                            <th></th>
                        </tr>
                        <?php $__currentLoopData = $allocations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allocation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <code><?php echo e($allocation->ip); ?></code>
                                </td>
                                <td class="middle">
                                    <?php if(is_null($allocation->ip_alias)): ?>
                                        <span class="label label-default"><?php echo app('translator')->getFromJson('strings.none'); ?></span>
                                    <?php else: ?>
                                        <code><?php echo e($allocation->ip_alias); ?></code>
                                    <?php endif; ?>
                                </td>
                                <td><code><?php echo e($allocation->port); ?></code></td>
                                <td class="col-xs-2 middle">
                                    <?php if($allocation->id === $server->allocation_id): ?>
                                        <a class="btn btn-xs btn-success disabled" data-action="set-default" data-allocation="<?php echo e($allocation->hashid); ?>" role="button"><?php echo app('translator')->getFromJson('strings.primary'); ?></a>
                                    <?php else: ?>
                                        <a class="btn btn-xs btn-default" data-action="set-default" data-allocation="<?php echo e($allocation->hashid); ?>" role="button"><?php echo app('translator')->getFromJson('strings.make_primary'); ?></a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div id="toggleActivityOverlay" class="overlay hidden">
                <i class="fa fa-refresh fa-spin"></i>
            </div>
        </div>
    </div>
    <div class="col-sm-4">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title"><?php echo app('translator')->getFromJson('server.config.allocation.help'); ?></h3>
            </div>
            <div class="box-body">
                <p><?php echo app('translator')->getFromJson('server.config.allocation.help_text'); ?></p>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
    ##parent-placeholder-45585b3461af0151e9d2a64e937701e41f93ebd3##
    <?php echo Theme::js('js/frontend/server.socket.js'); ?>

    <script>
        $(document).ready(function () {
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-allocation', $server)): ?>
            (function triggerClickHandler() {
                $('a[data-action="set-default"]:not(.disabled)').click(function (e) {
                    $('#toggleActivityOverlay').removeClass('hidden');
                    e.preventDefault();
                    var self = $(this);
                    $.ajax({
                        type: 'PATCH',
                        url: Router.route('server.settings.allocation', { server: Pterodactyl.server.uuidShort }),
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content'),
                        },
                        data: {
                            'allocation': $(this).data('allocation')
                        }
                    }).done(function () {
                        self.parents().eq(2).find('a[role="button"]').removeClass('btn-success disabled').addClass('btn-default').html('<?php echo e(trans('strings.make_primary')); ?>');
                        self.removeClass('btn-default').addClass('btn-success disabled').html('<?php echo e(trans('strings.primary')); ?>');
                    }).fail(function(jqXHR) {
                        console.error(jqXHR);
                        var error = 'An error occurred while trying to process this request.';
                        if (typeof jqXHR.responseJSON !== 'undefined' && typeof jqXHR.responseJSON.error !== 'undefined') {
                            error = jqXHR.responseJSON.error;
                        }
                        swal({type: 'error', title: 'Whoops!', text: error});
                    }).always(function () {
                        triggerClickHandler();
                        $('#toggleActivityOverlay').addClass('hidden');
                    })
                });
            })();
            <?php endif; ?>
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>