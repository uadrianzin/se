<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->getFromJson('server.config.database.header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <h1><?php echo app('translator')->getFromJson('server.config.database.header'); ?><small><?php echo app('translator')->getFromJson('server.config.database.header_sub'); ?></small></h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->getFromJson('strings.home'); ?></a></li>
        <li><a href="<?php echo e(route('server.index', $server->uuidShort)); ?>"><?php echo e($server->name); ?></a></li>
        <li><?php echo app('translator')->getFromJson('navigation.server.configuration'); ?></li>
        <li class="active"><?php echo app('translator')->getFromJson('navigation.server.databases'); ?></li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="<?php echo e($allowCreation && Gate::allows('create-database', $server) ? 'col-xs-12 col-sm-8' : 'col-xs-12'); ?>">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title"><?php echo app('translator')->getFromJson('server.config.database.your_dbs'); ?></h3>
            </div>
            <?php if(count($databases) > 0): ?>
                <div class="box-body table-responsive no-padding">
                    <table class="table table-hover">
                        <tbody>
                            <tr>
                                <th><?php echo app('translator')->getFromJson('strings.database'); ?></th>
                                <th><?php echo app('translator')->getFromJson('strings.username'); ?></th>
                                <th><?php echo app('translator')->getFromJson('strings.password'); ?></th>
                                <th><?php echo app('translator')->getFromJson('server.config.database.host'); ?></th>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reset-db-password', $server)): ?><td></td><?php endif; ?>
                            </tr>
                            <?php $__currentLoopData = $databases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $database): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="middle"><?php echo e($database->database); ?></td>
                                    <td class="middle"><?php echo e($database->username); ?></td>
                                    <td class="middle">
                                        <code class="toggle-display" style="cursor:pointer" data-toggle="tooltip" data-placement="right" title="Click to Reveal">
                                            <i class="fa fa-key"></i> &bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;
                                        </code>
                                        <code class="hidden" data-attr="set-password">
                                            <?php echo e(Crypt::decrypt($database->password)); ?>

                                        </code>
                                    </td>
                                    <td class="middle"><code><?php echo e($database->host->host); ?>:<?php echo e($database->host->port); ?></code></td>
                                    <?php if(Gate::allows('reset-db-password', $server) || Gate::allows('delete-database', $server)): ?>
                                        <td>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-database', $server)): ?>
                                                <button class="btn btn-xs btn-danger pull-right" data-action="delete-database" data-id="<?php echo e($database->id); ?>">
                                                    <i class="fa fa-fw fa-trash-o"></i>
                                                </button>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reset-db-password', $server)): ?>
                                                <button class="btn btn-xs btn-primary pull-right" style="margin-right:10px;" data-action="reset-password" data-id="<?php echo e($database->id); ?>">
                                                    <i class="fa fa-fw fa-refresh"></i> <?php echo app('translator')->getFromJson('server.config.database.reset_password'); ?>
                                                </button>
                                            <?php endif; ?>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="box-body">
                    <div class="alert alert-info no-margin-bottom">
                        <?php echo app('translator')->getFromJson('server.config.database.no_dbs'); ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php if($allowCreation && Gate::allows('create-database', $server)): ?>
        <div class="col-xs-12 col-sm-4">
            <div class="box box-success">
                <div class="box-header with-border">
                    <h3 class="box-title">Create New Database</h3>
                </div>
                <?php if($overLimit): ?>
                    <div class="box-body">
                        <div class="alert alert-danger no-margin">
                            You are currently using <strong><?php echo e(count($databases)); ?></strong> of your <strong><?php echo e($server->database_limit ?? '∞'); ?></strong> allowed databases.
                        </div>
                    </div>
                <?php else: ?>
                    <form action="<?php echo e(route('server.databases.new', $server->uuidShort)); ?>" method="POST">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="pDatabaseName" class="control-label">Database</label>
                                <div class="input-group">
                                    <span class="input-group-addon">s<?php echo e($server->id); ?>_</span>
                                    <input id="pDatabaseName" type="text" name="database" class="form-control" placeholder="database" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="pRemote" class="control-label">Connections</label>
                                <input id="pRemote" type="text" name="remote" class="form-control" value="%" />
                                <p class="text-muted small">This should reflect the IP address that connections are allowed from. Uses standard MySQL notation. If unsure leave as <code>%</code>.</p>
                            </div>
                        </div>
                        <div class="box-footer">
                            <?php echo csrf_field(); ?>

                            <p class="text-muted small">You are currently using <strong><?php echo e(count($databases)); ?></strong> of <strong><?php echo e($server->database_limit ?? '∞'); ?></strong> databases. A username and password for this database will be randomly generated after form submission.</p>
                            <input type="submit" class="btn btn-sm btn-success pull-right" value="Create Database" />
                        </div>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
    ##parent-placeholder-45585b3461af0151e9d2a64e937701e41f93ebd3##
    <?php echo Theme::js('js/frontend/server.socket.js'); ?>

    <script>
        $(function () {
            $('[data-toggle="tooltip"]').tooltip()
        });
        $('.toggle-display').on('click', function () {
            $(this).parent().find('code[data-attr="set-password"]').removeClass('hidden');
            $(this).hide();
        });
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reset-db-password', $server)): ?>
            $('[data-action="reset-password"]').click(function (e) {
                e.preventDefault();
                var block = $(this);
                $(this).addClass('disabled').find('i').addClass('fa-spin');
                $.ajax({
                    type: 'PATCH',
                    url: Router.route('server.databases.password', { server: Pterodactyl.server.uuidShort }),
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content'),
                    },
                    data: {
                        database: $(this).data('id')
                    }
                }).done(function (data) {
                    block.parent().parent().find('[data-attr="set-password"]').html(data.password);
                }).fail(function(jqXHR) {
                    console.error(jqXHR);
                    var error = 'An error occurred while trying to process this request.';
                    if (typeof jqXHR.responseJSON !== 'undefined' && typeof jqXHR.responseJSON.error !== 'undefined') {
                        error = jqXHR.responseJSON.error;
                    }
                    swal({
                        type: 'error',
                        title: 'Whoops!',
                        text: error
                    });
                }).always(function () {
                    block.removeClass('disabled').find('i').removeClass('fa-spin');
                });
            });
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-database', $server)): ?>
            $('[data-action="delete-database"]').click(function (event) {
                event.preventDefault();
                var self = $(this);
                swal({
                    title: '',
                    type: 'warning',
                    text: 'Are you sure that you want to delete this database? There is no going back, all data will immediately be removed.',
                    showCancelButton: true,
                    confirmButtonText: 'Delete',
                    confirmButtonColor: '#d9534f',
                    closeOnConfirm: false,
                    showLoaderOnConfirm: true,
                }, function () {
                    $.ajax({
                        method: 'DELETE',
                        url: Router.route('server.databases.delete', { server: '<?php echo e($server->uuidShort); ?>', database: self.data('id') }),
                        headers: { 'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content') },
                    }).done(function () {
                        self.parent().parent().slideUp();
                        swal.close();
                    }).fail(function (jqXHR) {
                        console.error(jqXHR);
                        swal({
                            type: 'error',
                            title: 'Whoops!',
                            text: (typeof jqXHR.responseJSON.error !== 'undefined') ? jqXHR.responseJSON.error : 'An error occurred while processing this request.'
                        });
                    });
                });
            });
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>