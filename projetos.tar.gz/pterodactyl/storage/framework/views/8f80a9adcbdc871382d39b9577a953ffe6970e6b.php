<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->getFromJson('server.files.edit.header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <h1><?php echo app('translator')->getFromJson('server.files.edit.header'); ?><small><?php echo app('translator')->getFromJson('server.files.edit.header_sub'); ?></small></h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->getFromJson('strings.home'); ?></a></li>
        <li><a href="<?php echo e(route('server.index', $server->uuidShort)); ?>"><?php echo e($server->name); ?></a></li>
        <li><a href="<?php echo e(route('server.files.index', $server->uuidShort)); ?>"><?php echo app('translator')->getFromJson('navigation.server.file_browser'); ?></a></li>
        <li class="active"><?php echo app('translator')->getFromJson('navigation.server.edit_file'); ?></li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title"><?php echo e($file); ?></h3>
                <div class="pull-right box-tools">
                    <a href="/server/<?php echo e($server->uuidShort); ?>/files#<?php echo e(rawurlencode($directory)); ?>" class="pull-right"><button class="btn btn-default btn-sm"><?php echo app('translator')->getFromJson('server.files.edit.return'); ?></button></a>
                </div>
            </div>
            <input type="hidden" name="file" value="<?php echo e($file); ?>" />
            <textarea id="editorSetContent" class="hidden"><?php echo e($contents); ?></textarea>
            <div class="overlay" id="editorLoadingOverlay"><i class="fa fa-refresh fa-spin"></i></div>
            <div class="box-body" style="height:500px;" id="editor"></div>
            <div class="box-footer with-border">
                <button class="btn btn-sm btn-primary" id="save_file"><i class="fa fa-fw fa-save"></i> &nbsp;<?php echo app('translator')->getFromJson('server.files.edit.save'); ?></button>
                <a href="/server/<?php echo e($server->uuidShort); ?>/files#<?php echo e(rawurlencode($directory)); ?>" class="pull-right"><button class="btn btn-default btn-sm"><?php echo app('translator')->getFromJson('server.files.edit.return'); ?></button></a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
    ##parent-placeholder-45585b3461af0151e9d2a64e937701e41f93ebd3##
    <?php echo Theme::js('js/frontend/server.socket.js'); ?>

    <?php echo Theme::js('vendor/ace/ace.js'); ?>

    <?php echo Theme::js('vendor/ace/ext-modelist.js'); ?>

    <?php echo Theme::js('vendor/ace/ext-whitespace.js'); ?>

    <?php echo Theme::js('js/frontend/files/editor.js'); ?>

    <script>
        $(document).ready(function () {
            Editor.setValue($('#editorSetContent').val(), -1);
            Editor.getSession().setUndoManager(new ace.UndoManager());
            $('#editorLoadingOverlay').hide();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>