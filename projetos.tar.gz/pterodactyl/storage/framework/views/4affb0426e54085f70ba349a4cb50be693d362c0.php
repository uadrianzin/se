<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->getFromJson('server.config.sftp.header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <h1><?php echo app('translator')->getFromJson('server.config.sftp.header'); ?><small><?php echo app('translator')->getFromJson('server.config.sftp.header_sub'); ?></small></h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->getFromJson('strings.home'); ?></a></li>
        <li><a href="<?php echo e(route('server.index', $server->uuidShort)); ?>"><?php echo e($server->name); ?></a></li>
        <li><?php echo app('translator')->getFromJson('navigation.server.configuration'); ?></li>
        <li class="active"><?php echo app('translator')->getFromJson('navigation.server.sftp_settings'); ?></li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title"><?php echo app('translator')->getFromJson('Conexão via SFTP'); ?></h3>
            </div>
            <div class="box-body">
                <div class="form-group">
                    <label class="control-label"><?php echo app('translator')->getFromJson('CONEXÃO PARA ANDROID'); ?></label>
                    <div>
                        <input type="text" class="form-control" readonly value="Servidor:<?php echo e($node->fqdn); ?>" />
                        <input type="text" class="form-control" readonly value="Porta:<?php echo e($node->daemonSFTP); ?>" />
                        </div>
                       
                     <div>
                          <label class="control-label"><?php echo app('translator')->getFromJson('CONEXÃO PARA PC'); ?></label>

                         <input type="text" class="form-control" readonly value="sftp://<?php echo e($node->fqdn); ?>:<?php echo e($node->daemonSFTP); ?>" /> 


                         </div>
 
                <div class="form-group">
                    <label for="password" class="control-label"><?php echo app('translator')->getFromJson('Nome De Usuário Para Conexão'); ?></label>
                    <div>
                        <input type="text" class="form-control" readonly value="<?php echo e(auth()->user()->username); ?>.<?php echo e($server->uuidShort); ?>" />
                    </div>
              <label for="password" class="control-label"><?php echo app('translator')->getFromJson('Senha Para Conexão'); ?></label>
                    <div>
                        <input type="text" class="form-control" readonly value="É A Mesma Senha do Seu Login" />
                    </div>
            </div>
            </div>
            <div>
                <h3 class="small text-muted no-margin-bottom"><?php echo app('translator')->getFromJson('Aviso,  Não Deletar Arquivos Que São Necessários Para Inicialização'); ?></h3>
              </div>
<div> 
<h3>ABAIXO ESTÁ O DOWNLOAND DO ES FILE EXPLORER PARA ANDROID</h3>
 <a href="https://es-file-explorer.br.uptodown.com/android">DOWNLOAND</a>    

 </div>
       
<div>

<h3>ABAIXO ESTÁ O DOWNLOAND DO FILEZILA PARA PC</h3>

 <a href="https://filezilla-project.org/download.php?platform=win64">DOWNLOAND</a>



 </div>

<div>
<h3> video mostrando como conecta no sftp pelo celular </h3>
<a href ="https://youtu.be/pY4z9uAr83Y">VIDEO </a>

 </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
    ##parent-placeholder-45585b3461af0151e9d2a64e937701e41f93ebd3##
    <?php echo Theme::js('js/frontend/server.socket.js'); ?>

@endsect

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>