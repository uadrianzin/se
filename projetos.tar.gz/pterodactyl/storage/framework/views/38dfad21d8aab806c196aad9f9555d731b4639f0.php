<?php $__env->startSection('title'); ?>
    <?php echo e($node->name); ?>: Configuration
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <h1><?php echo e($node->name); ?><small>Your daemon configuration file.</small></h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(route('admin.index')); ?>">Admin</a></li>
        <li><a href="<?php echo e(route('admin.nodes')); ?>">Nodes</a></li>
        <li><a href="<?php echo e(route('admin.nodes.view', $node->id)); ?>"><?php echo e($node->name); ?></a></li>
        <li class="active">Configuration</li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="nav-tabs-custom nav-tabs-floating">
            <ul class="nav nav-tabs">
                <li><a href="<?php echo e(route('admin.nodes.view', $node->id)); ?>">About</a></li>
                <li><a href="<?php echo e(route('admin.nodes.view.settings', $node->id)); ?>">Settings</a></li>
                <li class="active"><a href="<?php echo e(route('admin.nodes.view.configuration', $node->id)); ?>">Configuration</a></li>
                <li><a href="<?php echo e(route('admin.nodes.view.allocation', $node->id)); ?>">Allocation</a></li>
                <li><a href="<?php echo e(route('admin.nodes.view.servers', $node->id)); ?>">Servers</a></li>
            </ul>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-sm-8">
        <div class="box box-primary">
            <div class="box-header with-border">
                <h3 class="box-title">Configuration File</h3>
            </div>
            <div class="box-body">
                <pre class="no-margin"><?php echo e($node->getConfigurationAsJson(true)); ?></pre>
            </div>
            <div class="box-footer">
                <p class="no-margin">This file should be placed in your daemon's <code>config</code> directory in a file called <code>core.json</code>.</p>
            </div>
        </div>
    </div>
    <div class="col-sm-4">
        <div class="box box-success">
            <div class="box-header with-border">
                <h3 class="box-title">Auto-Deploy</h3>
            </div>
            <div class="box-body">
                <p class="text-muted small">To simplify the configuration of nodes it is possible to fetch the config from the panel. A token is required for this process. The button below will generate a token and provide you with the commands necessary for automatic configuration of the node. <em>Tokens are only valid for 5 minutes.</em></p>
            </div>
            <div class="box-footer">
                <button type="button" id="configTokenBtn" class="btn btn-sm btn-default" style="width:100%;">Generate Token</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
    ##parent-placeholder-45585b3461af0151e9d2a64e937701e41f93ebd3##
    <script>
    $('#configTokenBtn').on('click', function (event) {
        $.getJSON('<?php echo e(route('admin.nodes.view.configuration.token', $node->id)); ?>').done(function (data) {
            swal({
                type: 'success',
                title: 'Token created.',
                text: 'Your token will expire <strong>in 5 minutes.</strong><br /><br />' +
                      '<p>To auto-configure your node run the following command:<br /><small><pre>npm run configure -- --panel-url <?php echo e(config('app.url')); ?> --token ' + data.token + '</pre></small></p>',
                html: true
            })
        }).fail(function () {
            swal({
                title: 'Error',
                text: 'Something went wrong creating your token.',
                type: 'error'
            });
        });
    });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>