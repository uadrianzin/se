




<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title><?php echo e(config('app.name', 'Pterodactyl')); ?> - <?php echo $__env->yieldContent('title'); ?></title>
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        <meta name="_token" content="<?php echo e(csrf_token()); ?>">

        <link rel="apple-touch-icon" sizes="180x180" href="/favicons/apple-touch-icon.png">
        <link rel="icon" type="image/png" href="/favicons/favicon-32x32.png" sizes="32x32">
        <link rel="icon" type="image/png" href="/favicons/favicon-16x16.png" sizes="16x16">
        <link rel="manifest" href="/favicons/manifest.json">
        <link rel="mask-icon" href="/favicons/safari-pinned-tab.svg" color="#bc6e3c">
        <link rel="shortcut icon" href="/favicons/favicon.ico">
        <meta name="msapplication-config" content="/favicons/browserconfig.xml">
        <meta name="theme-color" content="#0e4688">

        <?php echo $__env->make('layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php $__env->startSection('scripts'); ?>
            <?php echo Theme::css('vendor/bootstrap/bootstrap.min.css?t={cache-version}'); ?>

            <?php echo Theme::css('vendor/adminlte/admin.min.css?t={cache-version}'); ?>

            <?php echo Theme::css('vendor/adminlte/colors/skin-blue.min.css?t={cache-version}'); ?>

            <?php echo Theme::css('vendor/sweetalert/sweetalert.min.css?t={cache-version}'); ?>

            <?php echo Theme::css('vendor/animate/animate.min.css?t={cache-version}'); ?>

            <?php echo Theme::css('css/pterodactyl.css?t={cache-version}'); ?>

            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">

            <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
            <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
            <![endif]-->
        <?php echo $__env->yieldSection(); ?>
    </head>
    <body class="hold-transition skin-blue fixed sidebar-mini">
        <div class="wrapper">
            <header class="main-header">
                <a href="<?php echo e(route('index')); ?>" class="logo">
                    <span class="logo-lg"><?php echo e(config('app.name', 'Pterodactyl')); ?></span>
                    <span class="logo-mini"><img src="/favicons/android-chrome-192x192.png"></span>
                </a>
                <nav class="navbar navbar-static-top">
                    <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </a>
                    <div class="navbar-custom-menu">
                        <ul class="nav navbar-nav">
                            <li class="user-menu">
                                <a href="<?php echo e(route('account')); ?>">
                                    <img src="https://www.gravatar.com/avatar/<?php echo e(md5(strtolower(Auth::user()->email))); ?>?s=160" class="user-image" alt="User Image">
                                    <span class="hidden-xs"><?php echo e(Auth::user()->name_first); ?> <?php echo e(Auth::user()->name_last); ?></span>
                                </a>
                            </li>
                            <?php if(isset($sidebarServerList)): ?>
                                <li>
                                    <a href="#" data-toggle="control-sidebar">
                                        <i class="fa fa-server"></i>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if(Auth::user()->root_admin): ?>
                                <li>
                                    <li><a href="<?php echo e(route('admin.index')); ?>" data-toggle="tooltip" data-placement="bottom" title="<?php echo app('translator')->getFromJson('strings.admin_cp'); ?>"><i class="fa fa-gears"></i></a></li>
                                </li>
                            <?php endif; ?>
                            <li>
                                <li><a href="<?php echo e(route('auth.logout')); ?>" id="logoutButton" data-toggle="tooltip" data-placement="bottom" title="<?php echo app('translator')->getFromJson('strings.logout'); ?>"><i class="fa fa-sign-out"></i></a></li>
                            </li>
                        </ul>
                    </div>
                </nav>
            </header>
            <aside class="main-sidebar">
                <section class="sidebar">
                    <?php if(isset($server->name) && isset($node->name)): ?>
                        <div class="user-panel">
                            <div class="info">
                              <p><?php echo e($server->name); ?></p>
                              <a href="#" id="server_status_icon"><i class="fa fa-circle text-default"></i> Checking...</a>
                            </div>
                        </div>
                    <?php endif; ?>
                    <ul class="sidebar-menu tree" data-widget="tree">
                        <li class="header"><?php echo app('translator')->getFromJson('navigation.account.header'); ?></li>
                        <li class="<?php echo e(Route::currentRouteName() !== 'account' ?: 'active'); ?>">
                            <a href="<?php echo e(route('account')); ?>">
                                <i class="fa fa-user"></i> <span><?php echo app('translator')->getFromJson('navigation.account.my_account'); ?></span>
                            </a>
                        </li>
                        <li class="<?php echo e(Route::currentRouteName() !== 'account.security' ?: 'active'); ?>">
                            <a href="<?php echo e(route('account.security')); ?>">
                                <i class="fa fa-lock"></i> <span><?php echo app('translator')->getFromJson('navigation.account.security_controls'); ?></span>
                            </a>
                        </li>
                        <li class="<?php echo e((Route::currentRouteName() !== 'account.api' && Route::currentRouteName() !== 'account.api.new') ?: 'active'); ?>">
                            <a href="<?php echo e(route('account.api')); ?>">
                                <i class="fa fa-code"></i> <span><?php echo app('translator')->getFromJson('navigation.account.api_access'); ?></span>
                            </a>
                        </li>
                        <li class="<?php echo e(Route::currentRouteName() !== 'index' ?: 'active'); ?>">
                            <a href="<?php echo e(route('index')); ?>">
                                <i class="fa fa-server"></i> <span><?php echo app('translator')->getFromJson('navigation.account.my_servers'); ?></span>
                            </a>
                        </li>
                        <?php if(isset($server->name) && isset($node->name)): ?>
                            <li class="header"><?php echo app('translator')->getFromJson('navigation.server.header'); ?></li>
                            <li class="<?php echo e(Route::currentRouteName() !== 'server.index' ?: 'active'); ?>">
                                <a href="<?php echo e(route('server.index', $server->uuidShort)); ?>">
                                    <i class="fa fa-terminal"></i> <span><?php echo app('translator')->getFromJson('navigation.server.console'); ?></span>
                                    <span class="pull-right-container muted muted-hover" href="<?php echo e(route('server.console', $server->uuidShort)); ?>" id="console-popout">
                                        <span class="label label-default pull-right" style="padding: 3px 5px 2px 5px;">
                                            <i class="fa fa-external-link"></i>
                                        </span>
                                    </span>
                                </a>
                            </li>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-files', $server)): ?>
                                <li
                                    <?php if(starts_with(Route::currentRouteName(), 'server.files')): ?>
                                        class="active"
                                    <?php endif; ?>
                                >
                                    <a href="<?php echo e(route('server.files.index', $server->uuidShort)); ?>">
                                        <i class="fa fa-files-o"></i> <span><?php echo app('translator')->getFromJson('navigation.server.file_management'); ?></span>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-subusers', $server)): ?>
                                <li
                                    <?php if(starts_with(Route::currentRouteName(), 'server.subusers')): ?>
                                        class="active"
                                    <?php endif; ?>
                                >
                                    <a href="<?php echo e(route('server.subusers', $server->uuidShort)); ?>">
                                        <i class="fa fa-users"></i> <span><?php echo app('translator')->getFromJson('navigation.server.subusers'); ?></span>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-schedules', $server)): ?>
                                <li
                                    <?php if(starts_with(Route::currentRouteName(), 'server.schedules')): ?>
                                        class="active"
                                    <?php endif; ?>
                                >
                                    <a href="<?php echo e(route('server.schedules', $server->uuidShort)); ?>">
                                        <i class="fa fa-clock-o"></i> <span><?php echo app('translator')->getFromJson('navigation.server.schedules'); ?></span>
                                        <span class="pull-right-container">
                                            <span class="label label-primary pull-right"><?php echo e(\Pterodactyl\Models\Schedule::select('id')->where('server_id', $server->id)->where('is_active', 1)->count()); ?></span>
                                        </span>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-databases', $server)): ?>
                                <li
                                    <?php if(starts_with(Route::currentRouteName(), 'server.databases')): ?>
                                    class="active"
                                    <?php endif; ?>
                                >
                                    <a href="<?php echo e(route('server.databases.index', $server->uuidShort)); ?>">
                                        <i class="fa fa-database"></i> <span><?php echo app('translator')->getFromJson('navigation.server.databases'); ?></span>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if(Gate::allows('view-startup', $server) || Gate::allows('access-sftp', $server) ||  Gate::allows('view-allocations', $server)): ?>
                                <li class="treeview
                                    <?php if(starts_with(Route::currentRouteName(), 'server.settings')): ?>
                                        active
                                    <?php endif; ?>
                                ">
                                    <a href="#">
                                        <i class="fa fa-gears"></i>
                                        <span><?php echo app('translator')->getFromJson('navigation.server.configuration'); ?></span>
                                        <span class="pull-right-container">
                                            <i class="fa fa-angle-left pull-right"></i>
                                        </span>
                                    </a>
                                    <ul class="treeview-menu">
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-name', $server)): ?>
                                            <li class="<?php echo e(Route::currentRouteName() !== 'server.settings.name' ?: 'active'); ?>"><a href="<?php echo e(route('server.settings.name', $server->uuidShort)); ?>"><i class="fa fa-angle-right"></i> <?php echo app('translator')->getFromJson('navigation.server.server_name'); ?></a></li>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-allocations', $server)): ?>
                                            <li class="<?php echo e(Route::currentRouteName() !== 'server.settings.allocation' ?: 'active'); ?>"><a href="<?php echo e(route('server.settings.allocation', $server->uuidShort)); ?>"><i class="fa fa-angle-right"></i> <?php echo app('translator')->getFromJson('navigation.server.port_allocations'); ?></a></li>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access-sftp', $server)): ?>
                                            <li class="<?php echo e(Route::currentRouteName() !== 'server.settings.sftp' ?: 'active'); ?>"><a href="<?php echo e(route('server.settings.sftp', $server->uuidShort)); ?>"><i class="fa fa-angle-right"></i> <?php echo app('translator')->getFromJson('navigation.server.sftp_settings'); ?></a></li>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-startup', $server)): ?>
                                            <li class="<?php echo e(Route::currentRouteName() !== 'server.settings.startup' ?: 'active'); ?>"><a href="<?php echo e(route('server.settings.startup', $server->uuidShort)); ?>"><i class="fa fa-angle-right"></i> <?php echo app('translator')->getFromJson('navigation.server.startup_parameters'); ?></a></li>
                                        <?php endif; ?>
                                    </ul>
                                </li>
                            <?php endif; ?>
                            <?php if(Auth::user()->root_admin): ?>
                                <li class="header"><?php echo app('translator')->getFromJson('navigation.server.admin_header'); ?></li>
                                <li>
                                    <a href="<?php echo e(route('admin.servers.view', $server->id)); ?>" target="_blank">
                                        <i class="fa fa-cog"></i> <span><?php echo app('translator')->getFromJson('navigation.server.admin'); ?></span>
                                    </a>
                                </li>
                            <?php endif; ?>
                        <?php endif; ?>
                    </ul>
                </section>
            </aside>
            <div class="content-wrapper">
                <section class="content-header">
                    <?php echo $__env->yieldContent('content-header'); ?>
                </section>
                <section class="content">
                    <div class="row">
                        <div class="col-xs-12">
                            <?php if(count($errors) > 0): ?>
                                <div class="alert alert-danger">
                                    <?php echo app('translator')->getFromJson('base.validation_error'); ?><br><br>
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <?php $__currentLoopData = Alert::getMessages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $messages): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="alert alert-<?php echo e($type); ?> alert-dismissable" role="alert">
                                        <?php echo $message; ?>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <?php echo $__env->yieldContent('content'); ?>
                </section>
            </div>
            <footer class="main-footer">
                <div class="pull-right small text-gray" style="margin-right:10px;margin-top:-7px;">
                    <strong><i class="fa fa-fw <?php echo e($appIsGit ? 'fa-git-square' : 'fa-code-fork'); ?>"></i></strong> <?php echo e($appVersion); ?><br />
                    <strong><i class="fa fa-fw fa-clock-o"></i></strong> <?php echo e(round(microtime(true) - LARAVEL_START, 3)); ?>s
                </div>
                Copyright &copy; 2015 - <?php echo e(date('Y')); ?> <a href="https://pterodactyl.io/">Pterodactyl Software</a>.
            </footer>
            <?php if(isset($sidebarServerList)): ?>
                <aside class="control-sidebar control-sidebar-dark">
                    <div class="tab-content">
                        <ul class="control-sidebar-menu">
                            <?php $__currentLoopData = $sidebarServerList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sidebarServer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="<?php echo e(route('server.index', $sidebarServer->uuidShort)); ?>" <?php if(isset($server) && $sidebarServer->id === $server->id): ?>class="active"<?php endif; ?>>
                                        <?php if($sidebarServer->owner_id === Auth::user()->id): ?>
                                            <i class="menu-icon fa fa-user bg-blue"></i>
                                        <?php else: ?>
                                            <i class="menu-icon fa fa-user-o bg-gray"></i>
                                        <?php endif; ?>
                                        <div class="menu-info">
                                            <h4 class="control-sidebar-subheading"><?php echo e(str_limit($sidebarServer->name, 20)); ?></h4>
                                            <p><?php echo e(str_limit($sidebarServer->description, 20)); ?></p>
                                        </div>
                                    </a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </aside>
            <?php endif; ?>
            <div class="control-sidebar-bg"></div>
        </div>
        <?php $__env->startSection('footer-scripts'); ?>
            <?php echo Theme::js('js/keyboard.polyfill.js?t={cache-version}'); ?>

            <script>keyboardeventKeyPolyfill.polyfill();</script>

            <?php echo Theme::js('js/laroute.js?t={cache-version}'); ?>

            <?php echo Theme::js('vendor/jquery/jquery.min.js?t={cache-version}'); ?>

            <?php echo Theme::js('vendor/sweetalert/sweetalert.min.js?t={cache-version}'); ?>

            <?php echo Theme::js('vendor/bootstrap/bootstrap.min.js?t={cache-version}'); ?>

            <?php echo Theme::js('vendor/slimscroll/jquery.slimscroll.min.js?t={cache-version}'); ?>

            <?php echo Theme::js('vendor/adminlte/app.min.js?t={cache-version}'); ?>

            <?php echo Theme::js('vendor/socketio/socket.io.v203.min.js?t={cache-version}'); ?>

            <?php echo Theme::js('vendor/bootstrap-notify/bootstrap-notify.min.js?t={cache-version}'); ?>

            <?php echo Theme::js('js/autocomplete.js?t={cache-version}'); ?>


            <?php if(Auth::user()->root_admin): ?>
                <script>
                    $('#logoutButton').on('click', function (event) {
                        event.preventDefault();

                        var that = this;
                        swal({
                            title: 'Do you want to log out?',
                            type: 'warning',
                            showCancelButton: true,
                            confirmButtonColor: '#d9534f',
                            cancelButtonColor: '#d33',
                            confirmButtonText: 'Log out'
                        }, function () {
                            window.location = $(that).attr('href');
                        });
                    });
                </script>
            <?php endif; ?>
        <?php echo $__env->yieldSection(); ?>
    </body>
</html>
